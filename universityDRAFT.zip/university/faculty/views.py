from django.shortcuts import render
from django.http import HttpResponse
from faculty.models import Facultydetails, Award, Studentdetails, Courseinfo, Enrollment
from django.db import connection
from django.core.paginator import Paginator
from django.contrib.auth.decorators import login_required

# Create your views here.

@login_required
def home(request):
    context = {'firstname':'Lyndon', 'lastname':'Stacy'}
    return render(request, 'faculty/home.html', context)
    
def dictfetchall(cursor):
    "Return all rows from a cursor as a dict"
    columns = [col[0] for col in cursor.description]
    return [
        dict(zip(columns, row))
        for row in cursor.fetchall()
    ]
@login_required    
def facultydetails(request):
 #   cursor = connection.cursor()
 #   cursor.execute('SELECT * FROM FACULTY_FACULTYDETAILS')
 #   faculty = dictfetchall(cursor)
    faculty = Facultydetails.objects.all()
    paginator = Paginator(faculty, 2)
    page = request.GET.get('page')
    facultydata = paginator.get_page(page)
    print(faculty)
    return render(request, 'faculty/facultydetails.html', {'data':facultydata})
    
@login_required    
def award(request):
    faculty = Facultydetails.objects.all()
    awarddata = ""
    if('firstname' in request.session):
        awarddata = Award.objects.filter(firstname = request.session['firstname'])
    if('fname' in request.GET and 'aname' not in request.GET):
        fname = request.GET.get('fname')
        request.session['firstname'] = fname
        return HttpResponse('Success')
    if('fname' in request.GET and 'aname' in request.GET):
        fname = request.GET.get('fname')
        aname = request.GET.get('aname')
        awarddata = Award.objects.filter(firstname = fname)
        for row in awarddata:
            if row.award == aname:
                return HttpResponse('Error')
        newdata = Award(firstname = fname, award = aname)
        newdata.save()
        return HttpResponse('Success')
    return render(request, 'faculty/award.html', {'faculty': faculty, 'award':awarddata})
    
    
@login_required    
def studentdetails(request):
    students = Studentdetails.objects.all()
    paginator = Paginator(students, 10)
    page = request.GET.get('page')
    studentdata = paginator.get_page(page)
    print(students)
    return render(request, 'faculty/studentdetails.html', {'data':studentdata})
    
@login_required    
def courseinfo(request):
    courses = Courseinfo.objects.all()
    paginator = Paginator(courses, 10)
    page = request.GET.get('page')
    coursedata = paginator.get_page(page)
    print(courses)
    return render(request, 'faculty/courseinfo.html', {'data':coursedata})
    
@login_required    
def enrollment(request):
    courseinformation = Courseinfo.objects.all()
    studentinfo = Studentdetails.objects.all()
    enrollmentdata = ""
    if('studentid' in request.session):
        enrollmentdata = Enrollment.objects.filter(studentid = request.session['studentid'])
    if('studentidnum' in request.GET and 'cname' not in request.GET):
        studentidnum = request.GET.get('studentidnum')
        request.session['studentid'] = studentidnum
        return HttpResponse('Success')
    if('studentidnum' in request.GET and 'cname' in request.GET):
        studentidnum = request.GET.get('studentidnum')
        cname = request.GET.get('cname')
        enrollmentdata = Enrollment.objects.filter(studentid = studentidnum, coursename = cname)
        for row in enrollmentdata:
            if row.course == cname:
                return HttpResponse('Error')
        newdata = Enrollment(studentid = studentidnum, coursename = cname)
        newdata.save()
        return HttpResponse('Success')
    return render(request, 'faculty/Enrollment.html', {'faculty': studentinfo,'courseinformation': courseinformation , 'Enrollment':enrollmentdata})